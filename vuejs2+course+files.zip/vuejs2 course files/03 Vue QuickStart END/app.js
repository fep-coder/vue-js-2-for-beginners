new Vue({

    el: '#app',
    template: 
    `
        <div class="text-center p-3">
            <h1 class="display-4">Button clicks: {{ clickCount }}</h1>
            <span class="badge">{{ message }}</span>
            <button class="btn btn-primary" v-on:click="handleClick">Click me</button>
        </div>
    `,
    data: {
        clickCount: 0
    },
    computed: {
        message() {
            return this.clickCount == 0 ? "Click the button to start" : `Button clicks: ${this.clickCount}`;
        }
    },
    methods: {
        handleClick() {
            this.clickCount++;
        }
    }
});