<template>
    <div class="container">
        <h1>Hello Vue</h1>
        <div class="row">
            <div class="col">
                <!-- <CustomComponent /> -->
                <!-- <CustomComponent></CustomComponent> -->
                <!-- <custom-component /> -->
                <my-component />
            </div>
        </div>
    </div>
</template>

<script>

import CustomComponent from './components/CustomComponent';

export default {
    components: {
        MyComponent: CustomComponent
    }
};
</script>