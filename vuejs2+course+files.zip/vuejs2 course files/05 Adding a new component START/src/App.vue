<template>
    <div>
        hello vue
    </div>
</template>

<script>

export default {
    components: {
    }
};
</script>