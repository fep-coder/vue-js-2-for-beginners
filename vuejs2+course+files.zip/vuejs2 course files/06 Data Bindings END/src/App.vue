<template>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1 class="display-4 text-center">Data Bindings</h1>

                <h4 class="bg-primary text-white p-3">Fruit: {{ fruit }}</h4>

                <h4 class="bg-dark text-white p-3">
                    Product: {{ product }} ${{ (productPrice + 1).toFixed(2) }}
                </h4>

                <h4 class="bg-dark text-white p-3">
                    Product: {{ product }} ${{ formattedPrice }}
                </h4>

                <h4 class="bg-secondary text-white p-3">
                    Product: {{ product }} ${{
                        getProductPriceWithTax(10).toFixed(2)
                    }}
                </h4>

                <h4 class="bg-secondary text-white p-3">
                    Product: {{ product }} ${{
                        getProductPriceWithTax(20).toFixed(2)
                    }}
                </h4>

                <h4 class="bg-info text-white p-3">
                    Product: {{ product }} {{ productPrice | currency }}
                </h4>

                <h4 class="bg-info text-white p-3">
                    Product: {{ product }} {{ productPrice | currency("USD", "de-DE") }}
                </h4>

                <h4 class="bg-warning text-white p-3">
                    Pet: {{ pet | capitalize | suffix }}
                </h4>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            fruit: "apples",
            product: "White shirt",
            productPrice: 4,
            pet: 'cat'
        };
    },
    computed: {
        formattedPrice() {
            // this.productPrice = 5;
            return (this.productPrice + 1).toFixed(2);
        }
    },
    methods: {
        getProductPriceWithTax(tax) {
            this.productPrice = 5;
            return this.productPrice + this.productPrice * (tax / 100);
        }
    },
    filters: {
        // currency(value, curr = "EUR", format = "en-US") {
        //     return new Intl.NumberFormat(format, {
        //         style: "currency",
        //         currency: curr
        //     }).format(value);
        // }
        capitalize(value) {
            return value[0].toUpperCase() + value.slice(1);
        },
        suffix(value) {
            return value + '(s)';
        }
    }
};
</script>
