import Vue from "vue";
import App from "./App.vue";

import "bootstrap/dist/css/bootstrap.min.css";

Vue.filter("currency", (value, curr = "EUR", format = "en-US") =>
    new Intl.NumberFormat(format, {
        style: "currency",
        currency: curr
    }).format(value)
);

Vue.config.productionTip = false;

new Vue({
    render: h => h(App)
}).$mount("#app");
