<template>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1 class="display-4 text-center">Data Bindings</h1>

                
            </div>
        </div>
    </div>
</template>

<script>

export default {
    components: {
    }
};
</script>