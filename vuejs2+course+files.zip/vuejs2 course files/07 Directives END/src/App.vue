<template>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1 class="display-4 text-center">Directives</h1>

                <!-- <text-binding /> -->
                <!-- <IfElse /> -->
                <!-- <AttributeBinding /> -->
                <Repeater />
            </div>
        </div>
    </div>
</template>

<script>
// import TextBinding from './components/TextBinding';
// import IfElse from './components/IfElse';
// import AttributeBinding from './components/AttributeBinding';
import Repeater from './components/Repeater';

export default {
    components: {
        // TextBinding,
        // IfElse,
        // AttributeBinding,
        Repeater,
    }
}
</script>
