<template>
    <div class="row">
        <div class="col">
            <h4 class="bg-info text-white p-3" v-bind:class="textColor">
                {{ fruit }} (v-if)
            </h4>

            <h4 class="p-3" :class="textAndBgColorToggle">Change Classes</h4>
            <button
                class="btn btn-primary btn-sm"
                v-on:click="toggleChangeClasses"
            >
                Change Classes
            </button>

            <h4 class="mt-3" :data-id="id" v-bind:style="styles">Data Attributes</h4>

            <h4 class="p-3" :class="id > 3 ? ['bg-dark', 'text-white'] : 'bg-light'">Class via Expression</h4>
            <button
                class="btn btn-primary btn-sm"
                v-on:click="incrementId"
            >
                +
            </button>

            <h4 :class="{ red: redClass }">Class via Object Syntax</h4>
            <button
                class="btn btn-primary btn-sm"
                v-on:click="redClassToggle"
            >
                Red Class Toggle
            </button>

            <h4 v-bind="multipleAttributes">Multiple Attributes</h4>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            fruit: "Grapes",
            textColor: "text-dark",
            changeClasses: false,
            id: 1,
            styles: { background: 'green', color: 'white', padding: '5px' },
            redClass: true
        };
    },
    computed: {
        textAndBgColorToggle() {
            return this.changeClasses
                ? ["bg-light", "text-dark"]
                : ["bg-dark", "text-light"];
        },
        multipleAttributes() {
            return {
                class: ['bg-dark', 'text-white'],
                style: { border: '1px solid red', padding: '5px' },
                'data-id': this.id
            }
        }
    },
    methods: {
        toggleChangeClasses() {
            this.changeClasses = !this.changeClasses;
        },
        incrementId() {
            this.id++;
        },
        redClassToggle() {
            this.redClass = !this.redClass;
        }
    }
};
</script>

<style scoped>

.red {
    color: red !important;
}

</style>