<template>
    <div class="row">
        <div class="col-6">
            <h4 class="bg-info text-white p-3" v-if="show">{{ fruit }} (v-if)</h4>
            <h4 class="bg-info text-white p-3" v-else>Fruit is hidden.</h4>

            <h4 class="bg-secondary text-white p-3" v-show="show">{{ fruit }} (v-show)</h4>

            <button class="btn btn-primary btn-sm" v-on:click="toggleFruit">Toggle fruit</button>
        </div>
        <div class="col-6">

            <h4 class="bg-info text-white p-3" v-if="counter == 1">Counter is 1.</h4>
            <h4 class="bg-info text-white p-3" v-else-if="counter == 2">Counter is 2.</h4>
            <h4 class="bg-info text-white p-3" v-else>{{ counter }}</h4>

            <button class="btn btn-primary btn-sm" v-on:click="counterButton">+</button>
        </div>
    </div>
</template>

<script>

export default {
    data() {
        return {
            fruit: 'Grapes',
            show: true,
            counter: 1
        }
    },
    methods: {
        toggleFruit() {
            this.show = !this.show;
        },
        counterButton() {
            this.counter++;
        }
    },
}
</script>
