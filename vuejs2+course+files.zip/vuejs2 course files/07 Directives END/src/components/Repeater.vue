<template>
    <div class="row">

        <div class="col-7">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(p, i) in products" :key="i">
                        <td>{{ p.id }}</td>
                        <td>{{ p.name }} ( Index: {{ i }}) </td>
                        <td>{{ p.price | currency }}</td>
                    </tr>
                </tbody>
            </table>
            <button class="btn btn-primary btn-sm" v-on:click="handleClick">
                Click
            </button>
        </div>

        <div class="col-5">
            <ul class="list-group">
                <li class="list-group-item" v-for="i in 5" :key="i">
                    {{ i }}
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
import Vue from "vue";

export default {
    data() {
        return {
            products: [
                { id: 1, name: "White shirt", price: 5.99 },
                { id: 2, name: "Blue shirt", price: 6.99 },
                { id: 3, name: "Black shirt", price: 7.99 },
                { id: 4, name: "Apples", price: 1.99 },
                { id: 5, name: "Grapes", price: 2.5 },
                { id: 6, name: "Watermelon", price: 1 }
            ]
        };
    },
    methods: {
        handleClick() {
            // this.products[0] = { id: 7, name: 'Grey shirt', price: 8.99 };
            Vue.set(this.products, 0, {
                id: 7,
                name: "Grey shirt",
                price: 8.99
            });
        }
    }
};
</script>
