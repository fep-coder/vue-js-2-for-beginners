<template>
    <div class="row">
        <div class="col">
            <h4 class="bg-info text-white p-3">{{ fruit }}</h4>

            <h4 class="bg-info text-white p-3" v-text="fruit">This text will be replaced.</h4>

            <h4 class="bg-info text-white p-3" v-text="p">This text will be replaced.</h4>

            <h4 class="bg-info text-white p-3" v-html="p">This text will be replaced.</h4>
        </div>
    </div>
</template>

<script>

export default {
    data() {
        return {
            fruit: 'Grapes',
            p: '<p>A paragraph</p>'
        }
    },
}
</script>
