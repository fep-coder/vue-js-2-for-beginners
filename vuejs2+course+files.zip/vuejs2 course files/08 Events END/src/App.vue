<template>
    <div class="container">

        <!-- <Events /> -->
        <!-- <EventPropagation /> -->
        <KeyboardModifiers />
    </div>
</template>

<script>

// import Events from './components/Events';
// import EventPropagation from './components/EventPropagation';
import KeyboardModifiers from './components/KeyboardModifiers';

export default {
    components: {
        // Events,
        // EventPropagation,
        KeyboardModifiers,
    }
}
</script>