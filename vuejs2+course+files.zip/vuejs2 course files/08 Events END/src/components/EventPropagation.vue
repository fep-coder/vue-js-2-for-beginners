<template>
    <div class="row">
        <div class="col">
            <h1 class="display-4 text-center">Event Propagation</h1>

            <div
                id="outerElement"
                class="bg-dark text-white p-3"
                @click="handleClick"
            >
                Outer Element
                <div
                    id="middleElement"
                    class="bg-info text-white p-3"
                    @click.stop.self="handleClick"
                >
                    Middle Element
                    <div
                        id="innerElement"
                        class="bg-primary text-white p-3"
                        @click.once="handleClick"
                    >
                        Inner Element
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    methods: {
        handleClick($event) {
            console.log(`Target: ${$event.target.id}\nCurrent Target ${$event.currentTarget.id}`);
            // console.log($event.bubbles);
            // console.log($event);
        }
    }
};
</script>
