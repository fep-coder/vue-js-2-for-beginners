<template>
    <div class="row">
        <div class="col">
            <h1 class="display-4 text-center">Events</h1>

            <h4
                class="bg-primary text-white p-3"
                v-on:click="fruit = 'Watermelon'"
            >
                {{ fruit }}
            </h4>

            <h4
                class="bg-secondary text-white p-3"
                v-on:click="fruit = $event.type"
            >
                {{ fruit }}
            </h4>

            <h4 class="bg-info text-white p-3" v-on:click="handleEvent">
                {{ fruit }}
            </h4>

            <h4
                class="bg-success text-white p-3"
                @click="handleEvent2('Apples', $event)"
            >
                {{ fruit }}
            </h4>

            <h4
                class="bg-primary text-white p-3"
                @mouseover="handleMultipleEvents"
                @mouseleave="handleMultipleEvents"
            >
                {{ multipleEvents }}
            </h4>

            <h4
                class="bg-primary text-white p-3"
                v-on="multipleEvents2"
            >
                {{ multipleEvents }}
            </h4>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            fruit: "Grapes",
            multipleEvents: "mouseout",
            multipleEvents2: {
                'mouseover': this.handleMultipleEvents,
                'mouseout': this.handleMultipleEvents
            }
        };
    },
    methods: {
        handleEvent($event) {
            this.fruit = $event.type;
        },
        handleEvent2(fruit, $event) {
            this.fruit = `${fruit} ${$event.type}`;
        },
        handleMultipleEvents($event) {
            if ($event.type == "mouseover") {
                this.multipleEvents = "mouseover";
            } else {
                this.multipleEvents = "mouseout";
            }
        }
    }
};
</script>
