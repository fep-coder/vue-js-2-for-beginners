<template>
    <div class="row">
        <div class="col">
            <h1 class="display-4 text-center">Keyboard Modifiers</h1>

            <div class="form-group">
                <input type="text" class="form-control" @keydown.ctrl="handleKeyDown">
                <br>
                <input type="text" class="form-control" @keydown.ctrl.exact="handleKeyDown">
                <h3>Key: {{ key }}</h3>
            </div>
            
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            key: ''
        }
    },
    methods: {
        handleKeyDown($event) {
            this.key = $event.key;
        }
    }
};
</script>
