<template>
    <div class="container">
        <h1 class="display-4 text-center">Events</h1>

    </div>
</template>

<script>

export default {
    components: {
    }
}
</script>