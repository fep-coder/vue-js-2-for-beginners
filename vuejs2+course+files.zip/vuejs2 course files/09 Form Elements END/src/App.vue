<template>
    <div class="container">
        <!-- <TwoWayManualBinding /> -->
        <!-- <TwoWayAutomaticBinding /> -->
        <!-- <BindingToFormElements /> -->
        <!-- <VModelModifiers /> -->
        <!-- <BindingToDifferentDataTypes /> -->
        <Validation />
    </div>
</template>

<script>

// import TwoWayManualBinding from './components/TwoWayManualBinding'
// import TwoWayAutomaticBinding from './components/TwoWayAutomaticBinding'
// import BindingToFormElements from './components/BindingToFormElements'
// import VModelModifiers from './components/VModelModifiers'
// import BindingToDifferentDataTypes from './components/BindingToDifferentDataTypes'
import Validation from './components/Validation'

export default {
    components: {
        // TwoWayManualBinding,
        // TwoWayAutomaticBinding,
        // BindingToFormElements,
        // VModelModifiers,
        // BindingToDifferentDataTypes,
        Validation,
    }
}
</script>