<template>
    <div class="row">
        <div class="col">
            <h1 class="display-4 text-center">
                Binding To Different Data Types
            </h1>

            <h4 class="bg-primary text-white p-3">Fruits: {{ fruits }}</h4>

            <div class="form-check" v-for="(fruit, i) in fruitsArray" :key="i">
                <label for="" class="form-check-label">
                    <input
                        type="checkbox"
                        class="form-check-input"
                        v-model="fruits"
                        :value="fruit"
                    />
                    {{ fruit }}
                </label>
            </div>

            <h4 class="text-white p-3" :class="elementClass">
                Class: {{ elementClass }}
            </h4>
            <div class="form-check">
                <label for="" class="form-check-label">
                    <input
                        type="checkbox"
                        class="form-check-input"
                        v-model="classToggle"
                    />
                    bg-dark
                </label>
            </div>

            <hr>

            <h4 class="text-white p-3" :class="classToggle2">
                Class: {{ classToggle2 }}
            </h4>
            <div class="form-check">
                <label for="" class="form-check-label">
                    <input
                        type="checkbox"
                        class="form-check-input"
                        v-model="classToggle2"
                        true-value="bg-dark"
                        false-value="bg-primary"
                    />
                    bg-dark
                </label>
            </div>

            <hr>

            <select v-model="classToggle2" class="form-control">
                <option :value="bgDark">Dark color</option>
                <option :value="bgPrimary">Primary color</option>
            </select>

            <label for="" class="form-check-label">
                <input type="radio" class="form-check-input" v-model="classToggle2" :value="bgDark"> Dark Color
            </label>
            <br>
            <label for="" class="form-check-label">
                <input type="radio" class="form-check-input" v-model="classToggle2" :value="bgPrimary"> Primary Color
            </label>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            fruitsArray: ["Apples", "Oranges", "Bananas", "Mandarines"],
            fruits: [],

            classToggle: false,
            classToggle2: "bg-primary",
            bgDark: 'bg-dark',
            bgPrimary: 'bg-primary'
        };
    },
    computed: {
        elementClass() {
            return this.classToggle ? "bg-dark" : "bg-primary";
        }
    }
};
</script>
