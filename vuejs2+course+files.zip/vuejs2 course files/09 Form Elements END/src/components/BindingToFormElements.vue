<template>
    <div class="row">
        <div class="col">
            <h1 class="display-4 text-center">Binding To Form Elements</h1>

            <h4 class="bg-primary text-white p-3">Fruit: {{ fruit }}</h4>
            <h4 class="bg-info text-white p-3">Citrus: {{ citrus }}</h4>
            <h4 class="bg-primary text-white p-3">Description: {{ description }}</h4>

            <div class="form-group">
                <label for="">Fruit</label>
                <input type="text" class="form-control" v-model="fruit">
            </div>

            <div class="form-group">
                <label for="">Description</label>
                <input type="text" class="form-control" v-model="description">
            </div>

            <div class="form-check">
                <label for="" class="form-check-label">
                    <input type="radio" class="form-check-input" v-model="fruit" value="Apples"> Apples
                </label>
            </div>
            <div class="form-check">
                <label for="" class="form-check-label">
                    <input type="radio" class="form-check-input" v-model="fruit" value="Grapefruit"> Grapefruit
                </label>
            </div>
            <hr>
            <div class="form-check" v-for="(f, index) in fruits" :key="index">
                <label for="" class="form-check-label">
                    <input type="radio" class="form-check-input" v-model="fruit" :value="f"> {{ f }}
                </label>
            </div>

            <div class="form-check">
                <label for="" class="form-check-label">
                    <input type="checkbox" class="form-check-input" v-model="citrus"> Citrus
                </label>
            </div>

            <div class="form-group">
                <select v-model="fruit" class="form-control">
                    <option v-for="(f, i) in fruits" :key="i" :value="f">{{ f }}</option>
                </select>
            </div>
            
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            fruit: 'Apples',
            fruits: ['Grapes', 'Mandarines', 'Bananas'],
            description: 'Fresh green apples',
            citrus: false
        };
    }
};
</script>
