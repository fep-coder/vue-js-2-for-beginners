<template>
    <div class="row">
        <div class="col">
            <h1 class="display-4 text-center">Two Way Manual Binding</h1>

            <div class="bg-info m-2 p-2 text-white">
                Data Value: {{ dataValue }}
            </div>
            <div class="bg-info m-2 p-2 text-white">
                Another Value: {{ anotherValue }}
            </div>

            <div class="bg-primary m-2 p-2 text-white">
                <div class="form-check">
                    <label for="" class="form-check-label">
                        <input
                            type="checkbox"
                            class="form-check-input"
                            v-on:change="handleChange"
                            v-bind:checked="dataValue"
                        />
                        Data Value
                    </label>
                </div>
            </div>

            <div class="m-2 p-2">
                <input
                    type="text"
                    class="form-control"
                    @input="handleChange"
                    v-bind:value="anotherValue"
                />
            </div>

            <div class="text-center m-2">
                <button class="btn btn-secondary" @click="reset">Reset</button>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            dataValue: false,
            anotherValue: ""
        };
    },
    methods: {
        handleChange($event) {
            // this.dataValue = $event.target.checked;
            if ($event.target.type == 'checkbox') {
                this.dataValue = $event.target.checked;
            } else {
                this.anotherValue = $event.target.value;
            }
        },
        reset() {
            this.dataValue = false;
            this.anotherValue = "";
        }
    }
};
</script>
