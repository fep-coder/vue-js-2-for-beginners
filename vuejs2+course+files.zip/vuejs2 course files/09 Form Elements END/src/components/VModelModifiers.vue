<template>
    <div class="row">
        <div class="col">
            <h1 class="display-4 text-center">v-model Modifiers</h1>

            <h4 class="bg-primary text-white p-3">Number: {{ number }}</h4>
            <h4 class="bg-info text-white p-3">Number + 10: {{ number + 10 }}</h4>
            
            <div class="form-group">
                <label for="">Number</label>
                <input type="number" class="form-control" v-model.number.lazy="number">
            </div>

            <h4 class="bg-primary text-white p-3">Fruit: ({{ fruit }})</h4>
            <div class="form-group">
                <label for="">Fruit</label>
                <input type="text" class="form-control" v-model.trim="fruit">
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            number: 20,
            fruit: 'Apples',
        };
    }
};
</script>
