<template>
    <div class="row">
        <div class="col">
            <h1 class="display-4 text-center">Validation</h1>

            <div class="bg-danger text-white my-2 p-2" v-if="errors">
                <h5>The following errors have been found:</h5>
                <ul>
                    <template v-for="(errors, outerIndex) in validationErrors">
                        <li v-for="(error, index) in errors" :key="outerIndex + '-' + index">{{error}}</li>
                    </template>
                </ul>
            </div>

            <h4 class="bg-primary text-white p-3">Product: {{ product }}</h4>
            <h4 class="bg-info text-white p-3">Category: {{ category }}</h4>
            <h4 class="bg-dark text-white p-3">Price: {{ price }}</h4>

            <form @submit.prevent="handleSubmit">
                <div class="form-group">
                    <label>Product</label>
                    <input v-model="product" class="form-control" />
                </div>
                <div class="form-group">
                    <label>Category</label>
                    <input v-model="category" class="form-control" />
                </div>
                <div class="form-group">
                    <label>Price</label>
                    <input type="number" v-model.number="price" class="form-control" />
                </div>
                <div class="text-center">
                    <button class="btn btn-primary" type="submit">Submit</button>
                </div>
            </form>
        </div>
    </div>
</template>

<script>

import validation from "../validation";
import Vue from "vue";

export default {
    data() {
        return {
            product: "",
            category: "",
            price: 0,
            validationErrors: {}
        };
    },
    watch: {
        product(value) {
            this.validateWatch("product", value);
        },
        category(value) {
            this.validateWatch("category", value);
        },
        price(value) {
            this.validateWatch("price", value);
        },
    },
    computed: {
        errors() {
            return Object.values(this.validationErrors).length;
        }
    },
    methods: {
        // handleSubmit() {
        //     console.log(`FORM SUBMITTED: ${this.product} ${this.category} ${this.price}`);
        // },
        validateWatch(propertyName, value) {
            this.validate(propertyName, value);
        },
        validate(propertyName, value) {
            let errors = [];

            Object(validation)[propertyName].forEach(v => {
                if (!v.validator(value)) {
                    errors.push(v.message);
                }
            });

            if (errors.length > 0) {
                Vue.set(this.validationErrors, propertyName, errors);
            } else {
                Vue.delete(this.validationErrors, propertyName);
            }
        },
        validateAll() {
            this.validate("product", this.product);
            this.validate("category", this.category);
            this.validate("price", this.price);

            return (this.errors > 0) ? false : true;
        },
        handleSubmit() {
            if (this.validateAll()) {
                console.log(`FORM SUBMITTED: ${this.product} ${this.category} ${this.price}`);
            }
        },
    }
};
</script>