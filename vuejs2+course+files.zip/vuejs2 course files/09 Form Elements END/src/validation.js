function required(name) {
    return {
        validator: (value) => value != '' && value !== undefined && value !== null,
        message: `A value is required for ${name}.`
    }
}

function minLength(name, minLength) {
    return {
        validator: (value) => String(value).length >= minLength,
        message: `The ${name} must be at least ${minLength} characters.`
    }
}

function alpha(name) {
    return {
        validator: (value) => /^[a-zA-Z]*$/.test(value),
        message: `${name} can contain only letters.`
    }
}

function numeric(name) {
    return {
        validator: (value) => /^[0-9]*$/.test(value),
        message: `${name} can contain only digits.`
    }
}

function minPrice(name, min) {
    return {
        validator: (value) => value >= min,
        message: `Minimum price must be at least ${min}.`
    }
}

export default {
    product: [minLength("Product Name", 3)],
    category: [required("Category"), alpha("Category")],
    price: [numeric("Price"), minPrice("Price", 2)],
}