<template>
    <div class="bg-dark text-white text-center m-2 p-3 content">
        <h1 class="display-4 text-center">Root Component</h1>
        <h3>{{ message }}</h3>

        <div class="row">

            <div class="col-12">
                <product-display v-bind:product="product">
                    <div slot-scope="data" class="bg-info text-left">
                        {{ data.propname }}: {{ data.propvalue }}
                    </div>
                </product-display>
            </div>

            <div class="col-12 mt-5">
                <slots>
                    <div class="bg-warning m-2 p-2 h3 text-dark">Slot element from parent.</div>

                    <div slot="top" class="bg-warning m-2 p-2 h3 text-dark">Top slot from parent.</div>

                    <div slot="bottom" class="bg-warning m-2 p-2 h3 text-dark">Bottom slot from parent.</div>

                </slots>
            </div>

            <div class="col-12 mt-5">
                <div class="form-group">
                    <input type="text" class="form-control" v-model="dogBreed">

                    <my-child-comp greeting="Hello from parent" v-bind:dog-breed="dogBreed" />
                </div>
            </div>

            <div class="col-12 mt-5">
                <ParentCustomEvents />
            </div>
        </div>
    </div>
</template>

<script>

import ChildComp from './components/Child';
import ParentCustomEvents from './components/ParentCustomEvents';
import Slots from './components/Slots';
import ProductDisplay from './components/ProductDisplay';

export default {
    name: 'TestApp',
    components: {
        MyChildComp: ChildComp,
        ParentCustomEvents,
        Slots,
        ProductDisplay,
    },
    data() {
        return {
            message: 'Message from the App (root) component.',
            dogBreed: 'Pit Bull',

            product: {
                name: 'White shirt',
                category: 'T-shirts',
                price: 6
            }
        }
    },
}
</script>