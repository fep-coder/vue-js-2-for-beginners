<template>
    <div class="bg-primary text-white text-center m-2 p-3 content">
        <h2>Child Component</h2>

        <h3>{{ message }}</h3>

        <h3>{{ greeting }}</h3>
        
        <h3>{{ dogBreed }}</h3>
        <h3>Dog: {{ dog }}</h3>
        <h3>Dog 2: {{ dog2 }}</h3>

    </div>
    <!-- <template src="./Child.html" /> -->
</template>

<script>

export default {
    props: ['greeting', 'dogBreed'],
    data() {
        return {
            message: 'Message from the Child component',
            dog: this.dogBreed
        }
    },
    computed: {
        dog2() {
            return this.dogBreed;
        }
    },
}
</script>

<style scoped>

div.content {
    border-bottom: 1px solid #ccc;
}

</style>