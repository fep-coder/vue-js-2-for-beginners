<template>
    <div class="bg-primary text-white text-center m-2 p-3 content">
        <h2>Child Custom Events</h2>

        <div class="form-group text-left">
            <label for="">Name</label>
            <input type="text" class="form-control" v-model="product.name">
        </div>

        <div class="form-group text-left">
            <label for="">Category</label>
            <input type="text" class="form-control" v-model="product.category">
        </div>

        <div class="form-group text-left">
            <label for="">Price</label>
            <input type="text" class="form-control" v-model="product.price">
        </div>

        <div class="mt-2">
            <button class="btn btn-info" v-on:click="doSubmit">Submit</button>
        </div>

    </div>
</template>

<script>

export default {
    props: ['initialProduct'],
    data() {
        return {
            product: this.initialProduct || {}
        }
    },
    methods: {
        doSubmit() {
            this.$emit('productSubmit', this.product);
        }
    }
}
</script>