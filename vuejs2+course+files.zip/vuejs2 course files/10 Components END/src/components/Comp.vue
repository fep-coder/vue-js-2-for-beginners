<template>
    <div class="row">
        <div class="col">
            <h1 class="display-4 text-center">Comp</h1>
        </div>
    </div>
</template>

<script>

export default {
    components: {},
    data() {
        return {}
    },
    methods: {
    }
};
</script>