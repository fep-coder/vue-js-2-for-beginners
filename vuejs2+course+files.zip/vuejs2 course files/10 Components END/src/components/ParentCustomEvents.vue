<template>
    <div class="bg-dark text-white text-center m-2 p-3 content">
        <h1 class="display-4 text-center">Parent Custom Events</h1>
        <h3>{{ productInfo }}</h3>

        <ChildCustomEvents :initial-product="product" v-on:productSubmit="updateProduct" />
    </div>
</template>

<script>

import ChildCustomEvents from './ChildCustomEvents'

export default {
    components: {
        ChildCustomEvents
    },
    data() {
        return {
            productInfo: 'Waiting for product update',
            product: {
                name: 'White shirt',
                category: 'T-shirts',
                price: 6
            }
        }
    },
    methods: {
        updateProduct(product) {
            this.productInfo = JSON.stringify(product);
        }
    },
}
</script>