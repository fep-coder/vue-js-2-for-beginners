<template>
    <ul>
        <h2>
            <li v-for="prop in Object.keys(product)" :key="prop">
                <slot v-bind:propname="prop" v-bind:propvalue="product[prop]">
                    {{ prop }} : {{ product[prop] }}
                </slot>
            </li>
        </h2>
    </ul>
</template>

<script>
export default {
    props: ["product"]
};
</script>
