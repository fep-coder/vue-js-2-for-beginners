<template>
    <div class="bg-primary text-white text-center m-2 p-3 content">
        <h2>Slots</h2>

        <slot>
            <h3>Inside slot</h3>
        </slot>

        <slot name="top">
            <h4>Top slot</h4>
        </slot>

        <slot name="bottom">
            <h4>Bottom slot</h4>
        </slot>

    </div>
</template>

<script>

export default {
    
}
</script>