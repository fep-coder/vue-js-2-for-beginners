import Vue from 'vue'
import App from './App.vue'

import 'bootstrap/dist/css/bootstrap.min.css';

// import ChildComp from './components/Child';
// Vue.component('g-child-component', ChildComp);

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')