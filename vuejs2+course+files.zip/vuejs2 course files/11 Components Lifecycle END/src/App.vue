<template>
    <div class="container">
        <div class="bg-primary text-white mt-3 p-2">
            <div class="form-check">
                <label>
                    <input
                        class="form-check-input"
                        type="checkbox"
                        v-model="checked"
                    />Checkbox
                </label>
            </div>
            Checked Value: {{ checked }}
        </div>

        <div class="mounted m-3" data-fruits="apples, oranges, grapes"></div>
        <h4>Fruits:</h4>
        <ul class="list-group">
            <li
                class="list-group-item"
                v-for="(fruit, index) in fruits"
                :key="index"
            >
                {{ fruit }}
            </li>
        </ul>

        <div class="text-white my-2">
            <button class="btn btn-light" @click="handleChange">Change</button>
        </div>

        <div class="bg-info p-2" v-if="checked">
            <message-display></message-display>
        </div>
    </div>
</template>

<script>
import MessageDisplay from "./components/MessageDisplay"

import Vue from 'vue';

export default {
    components: {
        MessageDisplay
    },
    data: function() {
        return {
            checked: true,
            fruits: []
        };
    },
    methods: {
        handleChange() {
            this.checked = !this.checked;
            this.fruits.reverse();

            Vue.nextTick(() => console.log(`Callback invoked`));
        }
    },
    beforeCreate() {
        console.log(`beforeCreate called: ${this.checked}`);
    },
    created() {
        console.log(`created called: ${this.checked}`);
        // console.log($el);
    },
    mounted() {
        console.log(this.$el);
        this.$el
            .getElementsByClassName("mounted")[0]
            .dataset.fruits.split(",")
            .forEach(fruit => this.fruits.push(fruit));
    },
    beforeUpdate() {
        console.log(
            `beforeUpdate called.
            Checked: ${this.checked}
            List Elements: ${this.$el.getElementsByTagName('li').length}
        `);
    },
    updated() {
        console.log(
            `updated called.
            Checked: ${this.checked}
            List Elements: ${this.$el.getElementsByTagName('li').length}
        `);
    },
    watch: {
        checked(newValue, oldValue) {
            console.log(`checked watch - old value = ${oldValue} - new value = ${newValue}`);
        },

        // immediate
        // checked: {
        //     handler: function (newValue, oldValue) {
        //         // respond to changes here
        //     },
        //     immediate: true
        // },

        // deep 
        // myObject: {
        //     handler: function (newValue, oldValue) {
        //         // respond to changes here
        //     },
        //     deep: true
        // }
    }
};
</script>
