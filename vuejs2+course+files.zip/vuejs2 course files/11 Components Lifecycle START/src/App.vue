<template>
    <div class="container">
        
        <div class="bg-primary text-white mt-3 p-2">
            <div class="form-check">
                <label>
                    <input class="form-check-input" type="checkbox" v-model="checked" />Checkbox
                </label>
            </div>
            Checked Value: {{ checked }}
        </div>

        <div class="bg-info p-2">
            <!-- <message-display></message-display> -->
        </div>

    </div>
</template>

<script>
// import MessageDisplay from "./components/MessageDisplay"

export default {
    components: {
        // MessageDisplay
    },
    data: function() {
        return {
            checked: true
        };
    },
}
</script>