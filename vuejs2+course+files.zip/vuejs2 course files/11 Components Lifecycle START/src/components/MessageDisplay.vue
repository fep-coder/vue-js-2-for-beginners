<template>
    <div class="bg-dark text-light text-center p-2">
        <div>Counter Value: {{ counter }}</div>
        <button class="btn btn-secondary" v-on:click="handleClick">Increment</button>
    </div>
</template>

<script>

export default {
    data: function() {
        return {
            counter: 0
        };
    },
    methods: {
        handleClick() {
            this.counter++;
        }
    }
};
</script>