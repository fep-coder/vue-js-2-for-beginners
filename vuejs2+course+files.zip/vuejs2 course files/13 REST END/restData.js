module.exports = function () {
    let data = {
        products: [
            { id: 1, name: "Apples", category: "Fruits", price: 1.00 },
            { id: 2, name: "Grapes", category: "Fruits", price: 1.99 },
            { id: 3, name: "White shirt", category: "T-shirts", price: 2.99 },
            { id: 4, name: "Watermelon", category: "Fruits", price: .50 },
            { id: 5, name: "Blue shirt", category: "T-shirts", price: 3.99 },
            { id: 6, name: "Green shirt", category: "T-shirts", price: 4.99 },
            { id: 7, name: "Mandarines", category: "Fruits", price: 2.00 },
            { id: 8, name: "Grapefruit", category: "Fruits", price: 2.50 },
            { id: 9, name: "Red shirt", category: "T-shirts", price: 5.99 },
            { id: 10, name: "Black shirt", category: "T-shirts", price: 5.99 },
        ]
    }
    return data
}