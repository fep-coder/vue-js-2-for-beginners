<template>
    <div>
        <h3>Product Display</h3>
        <table
            class="table table-sm table-bordered"
            :class="{ 'table-striped': useStripedTable }"
        >
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Price</th>
                <th></th>
            </tr>
            <tbody>
                <tr v-for="p in products" v-bind:key="p.id">
                    <td>{{ p.id }}</td>
                    <td>{{ p.name }}</td>
                    <td>{{ p.category }}</td>
                    <td>{{ p.price }}</td>
                    <td>
                        <button
                            class="btn btn-sm"
                            :class="editClass"
                            v-on:click="editProduct(p)"
                        >
                            Edit
                        </button>
                        <button
                            class="btn btn-sm"
                            :class="deleteClass"
                            v-on:click="deleteProduct(p)"
                        >
                            Delete
                        </button>
                    </td>
                </tr>
                <tr v-if="products.length == 0">
                    <td colspan="5" class="text-center">No Data</td>
                </tr>
            </tbody>
        </table>
        <div class="text-center">
            <button class="btn btn-primary" v-on:click="createNew">
                Create New
            </button>
        </div>
    </div>
</template>

<script>
import { mapState, mapGetters, mapMutations, mapActions } from "vuex";

export default {
    computed: {
        ...mapState(["products"]),
        ...mapGetters({
            tableClass: "prefs/tableClass",
            editClass: "prefs/editClass",
            deleteClass: "prefs/deleteClass"
        }),
        ...mapState({
            useStripedTable: state => state.prefs.stripedTable
        })
    },
    methods: {
        ...mapMutations({
            editProduct: "selectProduct",
            createNew: "selectProduct",
            setEditButtonColor: "prefs/setEditButtonColor",
            setDeleteButtonColor: "prefs/setDeleteButtonColor"
        }),
        ...mapActions({
            deleteProduct: "deleteProductAction"
        })
    },
    created() {
        this.$store.dispatch("getProductsAction");
        this.setEditButtonColor(false);
        this.setDeleteButtonColor(false);
    }
};
</script>
