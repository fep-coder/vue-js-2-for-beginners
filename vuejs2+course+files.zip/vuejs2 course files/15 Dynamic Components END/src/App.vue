<template>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center m-2">
                <button
                    class="btn btn-primary"
                    @click="selectComponent('table')"
                >
                    Standard Features
                </button>
                <button
                    class="btn btn-success"
                    @click="selectComponent('summary')"
                >
                    Advanced Features
                </button>
            </div>
            <div class="col-12">
                <component :is="selectedComponent"></component>
            </div>
        </div>
    </div>
</template>

<script>
import { mapState, mapMutations } from "vuex";

import ProductDisplay from "./components/ProductDisplay";
import ProductEditor from "./components/ProductEditor";

import LoadingMessage from "./components/LoadingMessage";

const DataSummary = () => ({
    // component: import("./components/DataSummary"),
    component: import(/* webpackChunkName: "advanced" */ "./components/DataSummary"),
    loading: LoadingMessage,
    delay: 100
});

export default {
    components: {
        ProductDisplay,
        ProductEditor,
        DataSummary
    },
    computed: {
        selectedComponent() {
            switch(this.selected) {
                case 'table':
                    return ProductDisplay;
                case 'editor':
                    return ProductEditor;
                case 'summary':
                    return DataSummary;
                default:
                    return ProductDisplay;
            }
        },
        ...mapState({
            selected: state => state.nav.selected
        })
    },
    methods: {
        ...mapMutations({
            selectComponent: 'nav/selectComponent'
        })
    },
    created() {
        this.$store.dispatch("getProductsAction");
    }
};
</script>
