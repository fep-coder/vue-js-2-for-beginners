<template>
    <div class="container">
        <div class="row">
            <div class="col">
                <router-view></router-view>
            </div>
        </div>
    </div>
</template>

<script>

export default {
    created() {
        this.$store.dispatch("getProductsAction");
    }
};

</script>