<template>
    <div class="container">
        <div class="row">
            <div class="row">
                <div class="col-12 text-center m-2">
                        <router-link
                            tag="button"
                            to="/products"
                            exact-active-class="btn-info"
                            class="btn btn-primary m-1"
                            >Products</router-link
                        >
                        <router-link
                            tag="button"
                            to="/preferences"
                            exact-active-class="btn-info"
                            class="btn btn-primary m-1"
                            >Preferences</router-link
                        >
                        <router-link
                            tag="button"
                            to="/named/tableleft"
                            exact-active-class="btn-info"
                            class="btn btn-primary m-1"
                            >Table Left</router-link
                        >
                        <router-link
                            tag="button"
                            to="/named/tableright"
                            exact-active-class="btn-info"
                            class="btn btn-primary m-1"
                            >Table Right</router-link
                        >
                </div>
            </div>
            <div class="col-12 m-2">
                <router-view></router-view>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    created() {
        this.$store.dispatch("getProductsAction");
    }
};
</script>

<style scoped>
/* li {
    text-align: left;
    color: white;
    background: red;
    cursor: pointer;
}

li:hover {
    opacity: 0.8;
} */

/* .router-link-active {
    background: yellow;
    color: black;
}

.router-link-exact-active {
    background: green;
    color: white;
} */
</style>
