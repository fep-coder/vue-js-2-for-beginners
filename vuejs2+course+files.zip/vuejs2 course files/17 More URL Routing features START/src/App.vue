<template>
    <div class="container">
        <div class="row">
            <div class="row">
                <div class="col text-center m-2">
                    <router-link to="/list" class="m-1">List</router-link>
                    <router-link to="/create" class="m-1">Create</router-link>
                </div>
            </div>
            <div class="col m-2">
                <router-view></router-view>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    created() {
        this.$store.dispatch("getProductsAction"); 
    }
};
</script>
