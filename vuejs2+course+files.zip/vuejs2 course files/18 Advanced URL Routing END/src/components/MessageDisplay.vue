<template>
    <h3 class="bg-success text-white text-center p-2">
        Message: {{ message }}
    </h3>
</template>

<script>

export default {
    props: ["message"]
};
</script>
