import Vue from 'vue'
import App from './App.vue'
import "bootstrap/dist/css/bootstrap.min.css";

// import Colorize from './directives/colorize';
// Vue.directive('colorize', Colorize);

// import mixin from './mixins/numbersMixin';
// Vue.mixin(mixin);

Vue.config.productionTip = false

import MathsPlugin from './plugins/maths';

Vue.use(MathsPlugin);

new Vue({
  render: h => h(App),
}).$mount('#app')
