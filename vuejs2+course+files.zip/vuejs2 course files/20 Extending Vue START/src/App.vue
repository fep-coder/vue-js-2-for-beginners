<template>
    <div class="m-2">
        <numbers />
    </div>
</template>

<script>
import Numbers from "./components/Numbers"

export default {
    components: { Numbers }
};

</script>
