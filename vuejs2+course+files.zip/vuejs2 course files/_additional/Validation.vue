<template>
    <div class="row">
        <div class="col">
            <h1 class="display-4 text-center">Validation</h1>

            <h4 class="bg-primary text-white p-3">Product: {{ product }}</h4>
            <h4 class="bg-info text-white p-3">Category: {{ category }}</h4>
            <h4 class="bg-dark text-white p-3">Price: {{ price }}</h4>

            <form>
                <div class="form-group">
                    <label>Product</label>
                    <input v-model="product" class="form-control" />
                </div>
                <div class="form-group">
                    <label>Category</label>
                    <input v-model="category" class="form-control" />
                </div>
                <div class="form-group">
                    <label>Price</label>
                    <input type="number" v-model.number="price" class="form-control" />
                </div>
                <div class="text-center">
                    <button class="btn btn-primary" type="submit">Submit</button>
                </div>
            </form>
        </div>
    </div>
</template>

<script>

import validation from "../validation";
import Vue from "vue";

export default {
    components: {},
    data() {
        return {
            product: "",
            category: "",
            price: 0,
        };
    },
    methods: {
        
    }
};
</script>